// var doraA = new Object();
// doraA.head = true;
// doraA.body = true;
// doraA.left_head = true;
// doraA.right_hand = true;

// var doraA = {
// 	head: true,
// 	body:true,
// 	left_hand:true,
// 	right_hand:true,
// 	left_leg:true,
// 	right_leg:true
// }

// DoraA.prototype.name = "哆啦A梦";
// DoraA.prototype.setAge = function(){console.log(age)};
// function DoraA(body,lef_hand,right_hand,head,left_leg,right_leg)
// {	
// 	this.body = body;
// 	this.head = head;
// 	this.left_leg = left_leg;
// 	this.left_hand = lef_hand;
// 	this.right_leg = right_leg;
// 	this.right_hand = right_hand;
// };
// var Person = new DoraA(true,true,true,true,true,true);
// 	Person.age = 15;
// show(Person);
// person.prototype = Person;
// function person(studentCount){
// 	studentCount = studentCount;
// 	setstudentCount = function()
// 	{console.log(studentCount);}
// };
// var teacher = new person(12);
// show(teacher);
